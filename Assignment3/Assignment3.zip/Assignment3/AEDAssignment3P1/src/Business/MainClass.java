/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Abhijeet
 */
public class MainClass {
    public static void main(String []args)
            
    {
        //ProductCatalog p= new ProductCatalog();
    SupplierDirectory sd=new SupplierDirectory();
    
    Supplier s1=sd.addSupplier();
    
Product a1=s1.getProductCatalog().addProduct();
Product a2=s1.getProductCatalog().addProduct();
//a1.setProductName("XD01");
//a1.setPrice(450);
    //Supplier s1=new Supplier();
   // Supplier s2=new Supplier();
    //ProductCatalog p= new ProductCatalog();
  // ProductCatalog p1= s1.getProductCatalog();
   
   /* Product a1=new Product();
    Product a2=new Product();*/
   s1.setSupplierName("HP");
    a1.setAvailability(5);
    a1.setPrice(750);
    a1.setProductName("XD01");
    a2.setAvailability(10);
    a2.setPrice(850);
    a2.setProductName("XD02");
    
    
    /*Product a3=new Product();
    a3.setAvailability(8);
    a3.setPrice(900);
    a3.setProductName("YD01");
    Product a4=new Product();
    a4.setAvailability(18);
    a4.setPrice(700);
    a4.setProductName("YD02");*/
    
    
   
    //p.addProduct(p2);
    
    //ArrayList<Product> pp = new ArrayList<Product>();
    //pp.add(a1);
   // pp.add(a2);
    
  //  ArrayList<Product> pp1 = new ArrayList<Product>();
   // pp1.add(a3);
    //pp1.add(a4);
    //p1.setProductList(pp1);
    //s1.setSupplierName("HP");
   // s1.setProductCatalog(p);
    //s2.setSupplierName("Dell");
     for(Supplier s : sd.getSupplierDirectory()){
          System.out.println("Supplier Name --->" + s.getSupplierName()); 
          int count=0;
          for(Product p : s.getProductCatalog().getProductList()){
              System.out.println(count + "product is "+ p.getProductName());
              count++;
          }
          }
        }
    
    
    
   
    
    
    
    
    
    }


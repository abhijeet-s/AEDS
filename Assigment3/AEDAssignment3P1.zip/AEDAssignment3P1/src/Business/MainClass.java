/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Abhijeet
 */
public class MainClass {
    public static void main(String []args)
            
    {
        
    SupplierDirectory sd=new SupplierDirectory();
    
    Supplier s1=sd.addSupplier();
    Supplier s2=sd.addSupplier();
    Supplier s3=sd.addSupplier();
            Supplier s4=sd.addSupplier();
                    Supplier s5=sd.addSupplier();
    
Product a11=s1.getProductCatalog().addProduct();
Product a12=s1.getProductCatalog().addProduct();
Product a21=s2.getProductCatalog().addProduct();
Product a22=s2.getProductCatalog().addProduct();
Product a31=s3.getProductCatalog().addProduct();
Product a32=s3.getProductCatalog().addProduct();
Product a41=s4.getProductCatalog().addProduct();
Product a42=s4.getProductCatalog().addProduct();
Product a51=s5.getProductCatalog().addProduct();
Product a52=s5.getProductCatalog().addProduct();

   s1.setSupplierName("HP");
    a11.setAvailability(15);
    a11.setPrice(750);
    a11.setProductName("HP01");
    a12.setAvailability(20);
    a12.setPrice(450);
    a12.setProductName("HP02");
    
       s2.setSupplierName("DELL");
    a21.setAvailability(15);
    a21.setPrice(750);
    a21.setProductName("DL01");
    a22.setAvailability(20);
    a22.setPrice(450);
    a22.setProductName("DL02");
    
       s3.setSupplierName("Lenovo");
    a31.setAvailability(15);
    a31.setPrice(750);
    a31.setProductName("LV01");
    a32.setAvailability(20);
    a32.setPrice(450);
    a32.setProductName("LV02");
    
       s4.setSupplierName("Apple");
    a41.setAvailability(15);
    a41.setPrice(750);
    a41.setProductName("AP01");
    a42.setAvailability(20);
    a42.setPrice(450);
    a42.setProductName("AP02");
    
       s5.setSupplierName("Toshiba");
    a51.setAvailability(15);
    a51.setPrice(750);
    a51.setProductName("TB01");
    a52.setAvailability(20);
    a52.setPrice(450);
    a52.setProductName("TB02");
 int countS=1;
    for(Supplier s : sd.getSupplierDirectory()){
        
          System.out.println(countS +". Supplier Name : " + s.getSupplierName()); 
          int countP=1;
          for(Product p : s.getProductCatalog().getProductList()){
              System.out.println(countP + ". Product : "+ p.getProductName());
              System.out.println(" Product Price : "+ p.getPrice());
              System.out.println(" Product Availbility : "+ p.getAvailability());
              System.out.println();
              countP++;
          }
          countS++;
          System.out.println("***************************************");
          System.out.println();
          }
    
        }
    
    
    
   
    
    
    
    
    
    }

